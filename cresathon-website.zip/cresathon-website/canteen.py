from flask import  Flask,render_template,request

site_url = "http://127.0.0.1:5000/"
webapp = Flask(__name__)
# uname,pwd,webpage
admin_data = {"admin1":["main","admin1","maincanteen.html"], "admin2":["bamboo","admin2","bamboo.html",], "admin3":["1styear","admin3","1st_year.html"]}
access = "granted"
b="crowed"
snack_count=[10,20,30]
@webapp.route('/')
def home():
    return  render_template("index(s).html")

@webapp.route('/menu')
def maenu():
    return  render_template("menu.html")

@webapp.route('/snack')
def sna():
    
    return  render_template("snack.html",d1=snack_count[0],d2=snack_count[1],d3=snack_count[2])

@webapp.route('/samosa')
def sa():
    return  render_template("samosa.html")

@webapp.route('/refresh')
def re():
    return  render_template("index(s).html",status=b)

@webapp.route('/update',methods=['GET','POST'])
def up():
    d1=request.form['d1']
    snack_count[0]=int(d1)
    return  render_template("maincanteen.html",u1=snack_count[0],u2=snack_count[1],u3=snack_count[2])

@webapp.route('/login', methods = ['GET','POST'])
def login():
    return render_template("login.html",site_url=site_url)
#
@webapp.route('/edit_menu', methods = ['GET','POST'])
def edit_menu_admin():
    if request.method == "POST":
        uname = request.form['username']
        pword = request.form['password']
        note = "invalid credentials!!! please re-enter your credentials"

        if (uname,pword) not in [(j[0], j[1]) for j in admin_data.values()]:

            return render_template("login.html",site_url=site_url,note = note)

        # elif access == "not granted":
        #     return render_template("need_login.html", site_url=site_url)

        else:
            for i in admin_data.keys():
                if uname == admin_data[i][0] and pword == admin_data[i][1]:
                    if(admin_data[i][2]=='maincanteen.html'):
                         
                        return render_template(admin_data[i][2],site_ur=site_url,u1=snack_count[0],u2=snack_count[1],u3=snack_count[2])
                    else:    
                        return render_template(admin_data[i][2],site_url=site_url)






# @webapp.route('/show_menu', methods = ['GET','POST'])
# def show_menu():
#     return render_template("###.html")


@webapp.route('/<data>')
def datas(data):
    global b
    a=int(data)
    if(a<5):
       
       b="Crowd status:No crowd"
       print(b)
    
    elif(a<11 and a>5):
      
      b="Crowd status:Average"
      print(b)
    elif(a<16 and a>10):
       
       b="Crowd status:Crowd"
       print(b)
    else:
       print(b)
       b="Over crowd"
    return render_template('index(s).html',status=b)
webapp.run(host='0.0.0.0')
